package com.example.chatapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class profilio : ComponentActivity() {
    private lateinit var text: EditText
    private lateinit var inputtext: TextView
    private lateinit var btn: Button
    private lateinit var button: Button
    private lateinit var clear: Button
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstance: Bundle?) {
        super.onCreate(savedInstance)
        setContentView(R.layout.activity_profilio)


        text = findViewById(R.id.editText)
        inputtext = findViewById(R.id.editTextt)
        clear=findViewById(R.id.clear)
        btn=findViewById(R.id.disableButton)
        button=findViewById(R.id.log)
        btn.setOnClickListener {
            val existingText = text.text.toString()
            val newText = inputtext.text.toString()
        text.setText( existingText+" "+newText);
        inputtext.setText("   ")
        }
        button.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        clear.setOnClickListener {
            text.setText("   ")

        }

    }

}