package com.example.chatapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.chatapplication.ui.theme.ChatApplicationTheme

class Registerpage : ComponentActivity() {
        private lateinit var btnSIGNUP: Button
        private lateinit var btnLOGIN: Button    

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_register)

            btnSIGNUP = findViewById(R.id.edt_SIGNUP)
            btnLOGIN = findViewById(R.id.edt_LOGIN)






            btnSIGNUP.setOnClickListener {
                val intent = Intent(this, SignUp::class.java)
                startActivity(intent)
            }
            btnLOGIN.setOnClickListener {
                val intent = Intent(this, LogIn::class.java)
                startActivity(intent)
            }

        }

                }

