package com.example.chatapplication

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity

class profilio : ComponentActivity() {
    private lateinit var text: EditText
    private lateinit var inputtext: TextView
    private lateinit var btn: Button
    private lateinit var button: Button
    private lateinit var clear: Button

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstance: Bundle?) {
        super.onCreate(savedInstance)
        setContentView(R.layout.activity_profilio)

        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        text = findViewById(R.id.editText)
        inputtext = findViewById(R.id.editTextt)
        clear = findViewById(R.id.clear)
        btn = findViewById(R.id.disableButton)
        button = findViewById(R.id.log)

        // Load saved text from SharedPreferences
        val savedText = sharedPreferences.getString("savedText", "")
        text.setText(savedText)

        btn.setOnClickListener {
            val existingText = text.text.toString()
            val newText = inputtext.text.toString()
            text.setText("$existingText $newText")
            inputtext.setText("")
        }

        button.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        clear.setOnClickListener {
            text.setText("")
        }
    }

    override fun onPause() {
        super.onPause()
        // Save the text to SharedPreferences
        val editor = sharedPreferences.edit()
        editor.putString("savedText", text.text.toString())
        editor.apply()
    }
}

